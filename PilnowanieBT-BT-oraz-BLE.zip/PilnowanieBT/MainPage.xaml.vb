﻿' The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409


Imports System.Xml.Serialization
Imports Windows.ApplicationModel.DataTransfer
Imports Windows.Devices.Bluetooth
Imports Windows.Devices.Bluetooth.Advertisement
Imports Windows.Devices.Enumeration
Imports Windows.Storage
''' <summary>
''' An empty page that can be used on its own or navigated to within a Frame.
''' </summary>




Public NotInheritable Class MainPage
    Inherits Page


#Region "Formatka - events"


    Private Sub uiPage_Loaded(sender As Object, e As RoutedEventArgs)
        App.moLista = New ObservableCollection(Of Urzadzenie)
        'ListaItems.ItemsSource = moLista
        'Dim oItem = New Urzadzenie
        'oItem.Nazwa = "alamakota"
        'moLista.Add(oItem)

        'ItemyGrp.Source = From c In moLista Group By c.SortGrp Into Group
        uiStart.Content = "Start"
        uiStart.IsChecked = False

        If App.msImportBuffer <> "" Then ListImport(App.msImportBuffer)

        fromDispatch()

    End Sub

    Private Async Sub uiStart_Click(sender As Object, e As RoutedEventArgs) Handles uiStart.Click
        Select Case uiStart.Label
            Case "Start"
                If Not Await UruchomSkanowanie() Then
                    uiStart.IsChecked = False
                    Exit Sub
                End If
                uiStart.Label = "Stop"
                uiStart.IsChecked = True
            Case Else
                If App.moDevWatcher IsNot Nothing AndAlso App.moDevWatcher.Status = DeviceWatcherStatus.Started Then App.moDevWatcher.Stop()
                uiStart.Label = "Start"
                uiStart.IsChecked = False
        End Select
    End Sub

    Private Sub GlobalObserwuj(bObserwuj As Boolean)
        For Each oItem In App.moLista
            oItem.Pilnowane = bObserwuj
            App.Zakoloruj(oItem)
        Next
    End Sub

    Private Sub uiSelectAll_Click(sender As Object, e As RoutedEventArgs) Handles uiSelectAll.Click
        GlobalObserwuj(True)
        fromDispatch()
    End Sub

    Private Sub uiSelectNone_Click(sender As Object, e As RoutedEventArgs) Handles uiSelectNone.Click
        GlobalObserwuj(False)
        fromDispatch()
    End Sub

    Private Sub uiListLoad_Click(sender As Object, e As RoutedEventArgs) Handles uiListLoad.Click
        App.msImportBuffer = ""
        Me.Frame.Navigate(GetType(ListaLoad))
        'Dim oPick = New Pickers.FileOpenPicker
        ''oPick.SuggestedStartLocation =
        ''ApplicationData.Current.RoamingFolder
        'oPick.FileTypeFilter.Add("txt")
        'Dim oFile = Await oPick.PickSingleFileAsync
        'If oFile Is Nothing Then Exit Sub

        'Dim sTxt = Await FileIO.ReadTextAsync(oFile)
        'ListImport(sTxt)
    End Sub
    Private Async Sub uiListSave_Click(sender As Object, e As RoutedEventArgs) Handles uiListSave.Click
        Dim sName = Await App.DialogBoxInput("resNazwaListy")
        If sName = "" Then Exit Sub

        Dim sTxt = ListExport()
        Dim oFile = Await App.GetRoamingFile(sName & ".txt", True)
        If oFile Is Nothing Then Exit Sub

        Await FileIO.WriteTextAsync(oFile, sTxt)
        Dim sListy = App.GetSettingsString("ListaList")
        sListy = sListy & "|" & sName
        App.SetSettingsString("ListaList", sListy)
    End Sub
    Private Async Sub uiListClear_Click(sender As Object, e As RoutedEventArgs) Handles uiListClear.Click
        If Not Await App.DialogBoxResYN("resAskConfirm") Then Exit Sub
        App.moLista.Clear()
        fromDispatch()
    End Sub

    Private Sub ListImport(sLista As String)
        Dim aArr = sLista.Split(vbCrLf)
        For Each oLine In aArr
            Dim aFld = oLine.Split("|")
            If aFld.GetUpperBound(0) = 1 Then
                Dim oNew = New Urzadzenie
                oNew.Nazwa = aFld(0)
                oNew.Adres = aFld(1)
                oNew.Pilnowane = True

                Dim bBylo = False       ' nie dodajemy, jesli juz jest (np. dwa razy wczytanie listy)
                For Each oItem In App.moLista
                    If oItem.Adres = aFld(1) Then
                        oItem.Pilnowane = True
                        bBylo = True
                        Exit For
                    End If
                Next
                If Not bBylo Then App.moLista.Add(oNew)
            End If
        Next
    End Sub

    Private Async Sub uiListImport_Click(sender As Object, e As RoutedEventArgs) Handles uiListImport.Click
        Dim oClipCont = Clipboard.GetContent
        Dim sTxt = Await oClipCont.GetTextAsync()
        If sTxt Is Nothing Then
            App.DialogBox("errorNoContens")
            Exit Sub
        End If

        ListImport(sTxt)
        fromDispatch()
    End Sub

    Private Function ListExport() As String
        Dim sTxt = ""
        For Each oItem In App.moLista
            sTxt = sTxt & oItem.Nazwa & "|" & oItem.Adres & vbCrLf
        Next
        Return sTxt
    End Function

    Private Sub uiListExport_Click(sender As Object, e As RoutedEventArgs) Handles uiListExport.Click
        Dim sTxt = ListExport()

        Dim oClipCont = New DataPackage
        oClipCont.RequestedOperation = DataPackageOperation.Copy
        oClipCont.SetText(sTxt)
        Clipboard.SetContent(oClipCont)

        App.DialogBoxRes("msgExportClip")

    End Sub

    Private Sub uiItem_Tapped(sender As Object, e As TappedRoutedEventArgs)
        Dim oItem = TryCast(TryCast(sender, Grid).DataContext, Urzadzenie)
        oItem.Pilnowane = Not oItem.Pilnowane
        'App.Zakoloruj(oItem)
        fromDispatch()
    End Sub

#End Region

    Public Sub fromDispatch()
        For Each oItem In App.moLista
            App.Zakoloruj(oItem)
        Next
        ListaItems.ItemsSource = From c In App.moLista
    End Sub

    Private Async Sub BTwatch_Added(sender As DeviceWatcher, oDI As DeviceInformation)
        Dim sNazwa As String = oDI.Name

        Debug.WriteLine("Found: " & sNazwa)
        Debug.WriteLine("Id=" & oDI.Id)

        Dim sId = oDI.Id
        Dim iInd = sId.LastIndexOf("-")
        If iInd > 0 Then sId = sId.Substring(iInd + 1)

        'For Each oProp In oDI.Properties
        'Debug.WriteLine(oProp.ToString)
        '  Found:  T93proB6DC
        ' [System.ItemNameDisplay, T93proB6DC]
        ' [System.Devices.DeviceInstanceId, ]
        ' [System.Devices.Icon, C:\Windows\System32\DDORes.dll,-2001]
        ' [System.Devices.GlyphIcon, C:\Windows\System32\DDORes.dll,-3001]
        ' [System.Devices.InterfaceEnabled, ]
        ' [System.Devices.IsDefault, ]
        ' [System.Devices.PhysicalDeviceLocation, ]
        ' [{A35996AB-11CF-4935-8B61-A6761081ECDF} 19, ]
        ' [System.Devices.Aep.CanPair, False]
        ' [System.Devices.Aep.IsPaired, True]
        ' [{A35996AB-11CF-4935-8B61-A6761081ECDF} 18, False]
        ' [{A35996AB-11CF-4935-8B61-A6761081ECDF} 13, False]
        'Next
        ' RSSI: A35996AB-11CF-4935-8B61-A6761081ECDF id 6
        ' IsConnected: j.w. id 7
        ' BluetoothLEAdvertisementWatcher 
        For Each oItem In App.moLista
            If oItem.Adres = sId Then
                If oItem.Widziane Then Exit Sub
                oItem.Widziane = True
                ' App.Zakoloruj(oItem)
                Await ListaItems.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, AddressOf fromDispatch)
                Exit Sub
            End If
        Next

        Dim oBluetoothLEAdvertisementWatcher = New BluetoothLEAdvertisementWatcher

        Dim oNew = New Urzadzenie
        oNew.Nazwa = sNazwa
        oNew.Adres = sId
        If sNazwa = "" Then ' oNew.Nazwa = "[addr: " & sId & "]"    ' REM, bo jest już osobne pole
            oNew.Nazwa = App.GetLangString("msgNoName")
        End If
        oNew.Widziane = True
        If oDI.Id.IndexOf("BluetoothLE") > -1 Then
            oNew.Proto = "(BLE)"
        Else
            oNew.Proto = "(BR/EDR)"
        End If

        App.moLista.Add(oNew)
        Await ListaItems.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, AddressOf fromDispatch)
    End Sub

    Private Async Sub BTwatch_Removed(sender As DeviceWatcher, oDIU As DeviceInformationUpdate)
        ' oDIU ma tylko ID, nie ma nazwy? pamietac trzeba ID?
        Debug.WriteLine("Removed: " & oDIU.Id)

        For Each oItem In App.moLista
            If oDIU.Id.Contains(oItem.Adres) Then
                If oItem.Pilnowane Then
                    oItem.Widziane = False
                Else
                    App.moLista.Remove(oItem)
                End If
                Await ListaItems.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, AddressOf fromDispatch)
                Exit For
            End If
        Next

    End Sub
    Private Async Sub BTwatch_Updated(sender As DeviceWatcher, oDIU As DeviceInformationUpdate)
        Debug.WriteLine("Updated: " & oDIU.Id)
        'For Each oProp In oDIU.Properties
        '    Debug.WriteLine(oProp.ToString)
        'Next

        Dim sNoName = App.GetLangString("msgNoName")

        For Each oItem In App.moLista
            If oDIU.Id.Contains(oItem.Adres) Then
                If oItem.Nazwa = sNoName Then
                    Dim sNazwa = ""
                    Try
                        sNazwa = oDIU.Properties.Item("System.ItemNameDisplay")
                    Catch ex As Exception
                    End Try
                    If sNazwa <> "" Then
                        oItem.Nazwa = sNazwa
                        Await ListaItems.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, AddressOf fromDispatch)
                    End If
                    Exit Sub
                End If
                Exit For
            End If
        Next
    End Sub

    Private Async Function UruchomSkanowanie() As Task(Of Boolean)
        If Not Await App.IsNetBTavailable(True) Then Return False

        'Dim sAQS = BluetoothDevice.GetDeviceSelector ' FromPairingState(False)
        ' System.Devices.DevObjectType:=5 AND System.Devices.Aep.ProtocolId:=\"{E0CBF06C-CD8B-4647-BB8A-263B43F0F974}\"";
        ' System.Devices.DevObjectType:=5 AND System.Devices.Aep.ProtocolId:="{BB7BB05E-5972-42B5-94FC-76EAA7084D49}".
        Dim sAQS = " System.Devices.DevObjectType:=5" ' ale to daje za dużo
        Dim sProtBT = "System.Devices.Aep.ProtocolId:=""{E0CBF06C-CD8B-4647-BB8A-263B43F0F974}"""
        Dim sProtLE = "System.Devices.Aep.ProtocolId:=""{BB7BB05E-5972-42B5-94FC-76EAA7084D49}"""
        sAQS = sAQS & " AND (" & sProtBT & " OR " & sProtLE & ")"

        App.moDevWatcher = DeviceInformation.CreateWatcher(sAQS)
        AddHandler App.moDevWatcher.Added, AddressOf BTwatch_Added
        AddHandler App.moDevWatcher.Removed, AddressOf BTwatch_Removed
        AddHandler App.moDevWatcher.Updated, AddressOf BTwatch_Updated
        ' EnumerationCompleted - ignoruje
        App.moDevWatcher.Start()
        Return True
    End Function


End Class
